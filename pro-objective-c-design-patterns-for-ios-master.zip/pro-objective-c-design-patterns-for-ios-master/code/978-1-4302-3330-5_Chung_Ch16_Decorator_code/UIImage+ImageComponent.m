//
//  UIImage+ImageComponent.m
//  Decorator
//
//  Created by Carlo Chung on 11/30/10.
//  Copyright 2010 Carlo Chung. All rights reserved.
//

#import "UIImage+ImageComponent.h"

/*
@implementation UIImage (ImageComponent)


@end
*/