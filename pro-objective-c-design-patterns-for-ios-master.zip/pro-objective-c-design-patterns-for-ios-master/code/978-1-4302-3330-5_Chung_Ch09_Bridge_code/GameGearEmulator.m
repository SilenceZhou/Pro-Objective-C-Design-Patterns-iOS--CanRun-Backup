//
//  GameGearEmulator.m
//  Bridge
//
//  Created by Carlo Chung on 11/26/10.
//  Copyright 2010 Carlo Chung. All rights reserved.
//

#import "GameGearEmulator.h"


@implementation GameGearEmulator

- (void) loadInstructionsForCommand:(ConsoleCommand) command
{
	// load specific instructions for
	// the Game Gear
}

- (void) executeInstructions
{
	// execute loaded instructions
}

@end
